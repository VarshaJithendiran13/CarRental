﻿namespace CarRental.Models.DTOs
{
    public class UserLoginResponseDTO
    {
        public string Token { get; set; }
    }
}
