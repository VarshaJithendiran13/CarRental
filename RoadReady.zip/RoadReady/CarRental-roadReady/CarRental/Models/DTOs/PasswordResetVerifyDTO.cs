﻿namespace CarRental.Models.DTOs
{
    public class PasswordResetVerifyDTO
    {
        public string ResetToken { get; set; }
    }

}
